#include <R.h>
#include <Rdefines.h>

SEXP nsreg() {
  return R_NamespaceRegistry;
}
