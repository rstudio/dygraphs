library(testthat)
test_check("magrittr")