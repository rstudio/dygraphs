#### -- Packrat Autoloader (version 0.4.2-7) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
