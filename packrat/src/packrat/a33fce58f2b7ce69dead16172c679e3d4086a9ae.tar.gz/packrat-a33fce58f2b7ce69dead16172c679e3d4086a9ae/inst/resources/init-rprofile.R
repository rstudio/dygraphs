#### -- Packrat Autoloader (version 0.4.4-24) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
