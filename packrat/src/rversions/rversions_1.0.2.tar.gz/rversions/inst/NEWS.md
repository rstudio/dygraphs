
# 1.0.1

* Rewritten using `xml2` and `curl` instead of `XML` and `RCurl`
  (Thanks to @jeroenooms)

# 1.0.0

First released version.
